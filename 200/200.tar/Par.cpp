#include "Par.h"

Par::Par(){}        // Constructor por defecto

Par::Par(string u, list<Cuac> c){
    usuario = u;
    cuacs = c;
}