#include "Par.h"


Par::Par(string u, list<Cuac> c){
    usuario = u;
    cuacs = c;
}