#include "DiccionarioCuacs.h"


void DiccionarioCuacs::last (int N){

}


void DiccionarioCuacs::date (Fecha f1, Fecha f2){

}
